
if(document.getElementById("year"))
  year.innerText = new Date().getFullYear();

function toggleTheme(){
  document.body.classList.toggle("dark");
}

function deleteCard(btn){
  btn.parentElement.remove();
}

function sendMessage(){
  alert("It has been sent.");
  return false;
}

function registerStudent(){
  let s = {
    id: sid.value,
    name: sname.value,
    pass: spass.value
  };
  localStorage.setItem(s.id, JSON.stringify(s));
  alert("Student Registered");
}

function login(){
  let data = localStorage.getItem(lid.value);
  if(!data){ alert("Wrong ID"); return; }
  let s = JSON.parse(data);
  if(s.pass === lpass.value){
    localStorage.setItem("current", data);
    location.href="profile.html";
  } else alert("Wrong Password");
}

if(document.getElementById("profile")){
  let s = JSON.parse(localStorage.getItem("current"));
  profile.innerText = "ID: "+s.id+" | Name: "+s.name;
}
